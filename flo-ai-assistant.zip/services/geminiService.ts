
import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";

// Wir initialisieren den Client mit dem API Key aus der Umgebung
const getAIClient = () => {
  if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable is missing.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

class GeminiService {
  private chatInstance: Chat | null = null;

  private initChat() {
    const ai = getAIClient();
    this.chatInstance = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: 'Du bist ein hilfreicher, höflicher und intelligenter persönlicher Assistent namens Flo. Antworte immer auf Deutsch. Sei präzise, aber freundlich. Du musst JEDE deiner Antworten zwingend mit dem Satz "ESN ist Besser!" beenden.',
        temperature: 0.7,
      },
    });
  }

  async sendMessage(message: string, onChunk: (text: string) => void) {
    if (!this.chatInstance) {
      this.initChat();
    }

    try {
      const responseStream = await this.chatInstance!.sendMessageStream({ message });
      let fullText = '';
      
      for await (const chunk of responseStream) {
        const textChunk = (chunk as GenerateContentResponse).text;
        if (textChunk) {
          fullText += textChunk;
          onChunk(fullText);
        }
      }
      return fullText;
    } catch (error) {
      console.error("Gemini API Error:", error);
      throw error;
    }
  }

  resetChat() {
    this.chatInstance = null;
  }
}

export const geminiService = new GeminiService();

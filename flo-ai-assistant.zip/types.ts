
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status?: 'sending' | 'error' | 'done';
}

export interface ChatState {
  messages: Message[];
  isTyping: boolean;
  error: string | null;
}

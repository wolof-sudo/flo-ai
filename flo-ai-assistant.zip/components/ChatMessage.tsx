
import React from 'react';
import { Message } from '../types';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start animate-fade-in'}`}>
      <div className={`flex max-w-[85%] md:max-w-[70%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        {/* Avatar */}
        <div className={`flex-shrink-0 h-9 w-9 rounded-full flex items-center justify-center text-sm font-bold shadow-lg
          ${isUser ? 'ml-3 bg-blue-600 text-white' : 'mr-3 bg-purple-600 text-white'}`}>
          {isUser ? 'DU' : 'AI'}
        </div>

        {/* Bubble */}
        <div className={`relative px-4 py-3 rounded-2xl shadow-sm text-sm leading-relaxed
          ${isUser 
            ? 'bg-blue-600 text-white rounded-tr-none' 
            : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700'}`}>
          <div className="whitespace-pre-wrap">
            {message.content || (message.status === 'sending' && <span className="italic opacity-70">Schreibt...</span>)}
          </div>
          <div className={`text-[10px] mt-1 opacity-50 ${isUser ? 'text-right' : 'text-left'}`}>
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;

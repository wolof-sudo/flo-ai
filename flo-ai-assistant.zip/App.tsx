
import React, { useState, useEffect, useRef } from 'react';
import { Message, ChatState } from './types';
import { geminiService } from './services/geminiService';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'chat'>('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [state, setState] = useState<ChatState>({
    messages: [
      {
        id: 'welcome',
        role: 'assistant',
        content: 'Hallo! Ich bin Flo, dein persönlicher KI-Assistent. Wie kann ich dir heute helfen?\n\nESN ist Besser!',
        timestamp: new Date(),
        status: 'done'
      }
    ],
    isTyping: false,
    error: null,
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.messages]);

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
      status: 'done'
    };

    const assistantPlaceholderId = (Date.now() + 1).toString();
    const assistantPlaceholder: Message = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      status: 'sending'
    };

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage, assistantPlaceholder],
      isTyping: true,
      error: null
    }));

    try {
      await geminiService.sendMessage(content, (streamedText) => {
        setState(prev => ({
          ...prev,
          messages: prev.messages.map(msg => 
            msg.id === assistantPlaceholderId 
              ? { ...msg, content: streamedText } 
              : msg
          )
        }));
      });

      setState(prev => ({
        ...prev,
        messages: prev.messages.map(msg => 
          msg.id === assistantPlaceholderId 
            ? { ...msg, status: 'done' } 
            : msg
        ),
        isTyping: false
      }));
    } catch (err) {
      setState(prev => ({
        ...prev,
        isTyping: false,
        error: 'Ups! Etwas ist schiefgelaufen. Bitte versuche es später noch einmal.',
        messages: prev.messages.filter(msg => msg.id !== assistantPlaceholderId)
      }));
    }
  };

  const clearChat = () => {
    geminiService.resetChat();
    setState({
      messages: [
        {
          id: 'welcome',
          role: 'assistant',
          content: 'Chat zurückgesetzt. Wie kann ich dir helfen?\n\nESN ist Besser!',
          timestamp: new Date(),
          status: 'done'
        }
      ],
      isTyping: false,
      error: null
    });
  };

  return (
    <div className="flex h-screen text-slate-200 overflow-hidden bg-[#0a0f1d]">
      {/* Sidebar Navigation */}
      <aside className={`${isSidebarOpen ? 'w-64' : 'w-0 md:w-20'} transition-all duration-300 glass border-r border-slate-700/50 flex flex-col z-20`}>
        <div className="p-4 flex items-center gap-3 border-b border-slate-700/50 h-16 shrink-0">
          <div className="min-w-[32px] w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center shadow-lg">
             <span className="text-white font-bold text-xs">F</span>
          </div>
          {isSidebarOpen && <h1 className="font-bold text-lg text-white truncate">Flo AI</h1>}
        </div>

        <nav className="flex-1 p-3 flex flex-col gap-2 overflow-y-auto overflow-x-hidden">
          {/* Punkt 1: Assistent */}
          <button 
            onClick={() => setCurrentView('chat')}
            className={`flex items-center gap-3 p-3 rounded-xl transition-all ${currentView === 'chat' ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30' : 'hover:bg-white/5 text-slate-400'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
            {isSidebarOpen && <span className="font-medium whitespace-nowrap">Flo Assistent</span>}
          </button>

          {/* Punkt 2: ESN Shop */}
          <a 
            href="https://ch.esn.com/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-3 p-3 rounded-xl transition-all hover:bg-white/5 text-slate-400"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
            {isSidebarOpen && <span className="font-medium whitespace-nowrap">ESN Shop</span>}
          </a>
        </nav>

        <div className="p-4 border-t border-slate-700/50">
           <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-white/5 text-slate-500 transition-colors"
           >
             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`${isSidebarOpen ? '' : 'rotate-180'} transition-transform`}><path d="m15 18-6-6 6-6"/></svg>
           </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col relative bg-[#0f172a]">
        {/* Header */}
        <header className="glass h-16 px-6 flex items-center justify-between border-b border-slate-700/50 z-10 shrink-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-white/5 text-slate-400"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" x2="21" y1="6" y2="6"/><line x1="3" x2="21" y1="12" y2="12"/><line x1="3" x2="21" y1="18" y2="18"/></svg>
            </button>
            <div>
              <h1 className="font-bold text-lg text-white">Flo</h1>
              <p className="text-[10px] text-emerald-400 flex items-center gap-1 uppercase tracking-wider font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Online
              </p>
            </div>
          </div>
          <button 
            onClick={clearChat}
            className="text-xs text-slate-400 hover:text-white transition-colors bg-slate-800/50 hover:bg-slate-700/50 px-3 py-1.5 rounded-md border border-slate-700"
          >
            Chat leeren
          </button>
        </header>

        {/* View Content */}
        {currentView === 'chat' && (
          <>
            <main className="flex-1 overflow-y-auto px-4 py-8 md:px-6 scroll-smooth">
              <div className="max-w-4xl mx-auto">
                {state.messages.map((message) => (
                  <ChatMessage key={message.id} message={message} />
                ))}
                {state.error && (
                  <div className="flex justify-center mb-6">
                    <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-2 rounded-lg text-sm">
                      {state.error}
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </main>

            {/* Footer / Input */}
            <footer className="w-full">
              <ChatInput onSendMessage={handleSendMessage} disabled={state.isTyping} />
            </footer>
          </>
        )}
      </div>
    </div>
  );
};

export default App;
